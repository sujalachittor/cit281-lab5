/*
    CIT 281 Lab 5
    Name: Sujala Chittor
*/

let fastify = require("fastify")();

const students = [
    {
      id: 1,
      last: "Last1",
      first: "First1",
    },
    {
      id: 2,
      last: "Last2",
      first: "First2",
    },
    {
      id: 3,
      last: "Last3",
      first: "First3",
    }
  ];


let current_reply = undefined;
function sendData(err, data) {
    if (err) {
        current_reply
        .code(404)
        .header("Content-Type", "text/text; charset=utf-8")
        .send("error");  
    } else {
        current_reply
        .code(200)
        .header("Content-Type", "application/json; charset=utf-8")
        .send(data);
    }
}



fastify.get("/cit/student", (request, reply) => {
    current_reply = reply;
    
    let data = students;
    //for (s of students) 
    //{data += s.first + " " + s.last + "\n" } 
    sendData(false, data);
});

fastify.get("/cit/student/:id", (request, reply) => {
    current_reply = reply;
    
    let data = {};
    let student_number = parseInt(request.params.id);
    for (s of students) 
        if (s.id == student_number) 
            data = s; 
    sendData(data == "", data);
});
fastify.post("/cit/add", (request, reply) => {
  current_reply = reply;
  let new_student_object = request.body;
  new_student_object.id = 1;
  for (s of students)
    if (new_student_object.id <= s.id)
      {new_student_object.id = s.id + 1}
  students.push(new_student_object)
  reply
  .code(200)
  .header("Content-Type", "application/json; charset=utf-8")
  .send(new_student_object);
});
fastify.get("*", (request, reply) => {
  current_reply = reply;
  sendData(true, "error");
});



// Start server and listen to requests using Fastify
const listenIP = "localhost";
const listenPort = 8080;
fastify.listen(listenPort, listenIP, (err, address) => {
  if (err) {
    console.log(err);
    process.exit(1);
  }
  console.log(`Server listening on ${address}`);
})

